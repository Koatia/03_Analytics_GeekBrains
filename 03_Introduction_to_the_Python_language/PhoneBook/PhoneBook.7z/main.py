from GUI_version import *


if __name__ == "__main__":
    print("\033[H\033[J")  # Очистка консоли
    mainMenu()
